package lab2;

import javax.swing.*;

@SuppressWarnings("serial")
public class Details extends JFrame {
	
	Details()
	{
	  setDefaultCloseOperation(javax.swing.
	  WindowConstants.DISPOSE_ON_CLOSE);
	  setTitle("Welcome");
	  setSize(400, 600);
	}
}
