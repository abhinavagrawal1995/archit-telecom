package lab2;
import javax.swing.*;

import ABIdb.dbfunc;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class Login extends JFrame implements ActionListener
{
	String allsql="drop table abi2user;create table abi2user(name varchar(50) PRIMARY KEY, pass varchar(50), role int);insert into abi2user values('admin','Admin',0);insert into abi2user values('teacher1','Teach1',1);insert into abi2user values('teacher2','Teach2',1);insert into abi2user values('student1','Stud1',2);insert into abi2user values('student2','Stud2',2);insert into abi2user values('student3','Stud3',2);";
	dbfunc test = new dbfunc(allsql);
	
		JButton SUBMIT;
		JPanel panel;
		JLabel label1,label2;
		final JTextField  text1,text2;
		Login()
		{
			label1 = new JLabel();
			label1.setText("Username:");
			text1 = new JTextField(15);
	 
			label2 = new JLabel();
			label2.setText("Password:");
			text2 = new JPasswordField(15);
	  
			SUBMIT=new JButton("SUBMIT");
	   
			panel=new JPanel(new GridLayout(3,1));
			panel.add(label1);
			panel.add(text1);
			panel.add(label2);
			panel.add(text2);
			panel.add(SUBMIT);
			add(panel,BorderLayout.CENTER);
			SUBMIT.addActionListener(this);
			setTitle("LOGIN FORM");
		}
		
		public void actionPerformed(ActionEvent ae)
		{
			String value1=text1.getText();
			String value2=text2.getText();
			String sql = null;
			person curr=new person();
			curr=person.login(value1,value2);
			if (curr!=null) {
				if(curr.role==0){
					sql="Select * from abi2user";
				}
				else if(curr.role==1){
					sql="Select * from abi2user where role>0";
				}
				else if(curr.role==2){
					sql="Select * from abi2user where role=2";
				}
				ArrayList<person> people=new ArrayList<person>();
				
				people=person.getpeople(sql);				
				
				Details page=new Details();
				page.setVisible(true);
				JLabel label = new JLabel("<html><h1>Welcome:"+value1+"</h1><br><br>"+person.showpeople(people)+"</HTML>");
				page.getContentPane().add(label);
			}
			else{
				System.out.println("Invalid username or password");
				JOptionPane.showMessageDialog(this,"Incorrect login or password",
						"Error",JOptionPane.ERROR_MESSAGE);
			}
		}
	 }
	  	