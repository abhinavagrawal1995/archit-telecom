package lab2;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ABIdb.dbfunc;

public class person{
	String name;
	String pass;
	int role;
	
	person(String name,String pass,int role){
		this.name=name;
		this.pass=pass;
		this.role=role;	
	}
	person(){
		
	}
	
	static person login(String pname,String pass){
		
		String sql="select * from abi2user where name like '"+ pname + "' and pass like '"+pass+"';";
		System.out.println(sql+"\n");
		ArrayList<person> people1=person.getpeople(sql);
		if(people1.size()==1){
			System.out.print("\nLogged In as "+people1.get(0).name);
			return people1.get(0);
		}
		return null;
	}
	
	static ArrayList<person> getpeople(String sql){
		ArrayList<person> people=new ArrayList<person>();
		List<Map<String, String>> reslist;
		try {
			reslist = dbfunc.select(sql);
			for (Map<String,String> map : reslist) {
				person p =new person(map.get("name"),map.get("pass"),Integer.parseInt(map.get("role")));  	
				people.add(p);
			}
			return people;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();			
		}
		return null;
		  
	}
	static void showp(person p){
		
		System.out.print("\nname is " +  p.name);
	    System.out.print(", pass is " + p.pass);
	    System.out.print(", role is " + p.role);
	}
	static String showpeople(ArrayList<person> people){		
		String str="";
		for (person p : people) {			
			str+="<br>name : " +  p.name + ", role : " + p.role + "<br>";
		}
		return str;
	}
}