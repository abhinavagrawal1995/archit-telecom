//this program uses the dbfunc package which provides functions to create db, connect, and select/insert/update/delete data

package lab2;
import java.sql.SQLException;
import java.util.Scanner;

import ABIdb.*;
import javax.swing.JOptionPane;
import lab2.Login;




public class Student 
{	
	static Scanner sc = new Scanner(System.in);	
	static String sql; 	
	
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		
		try
		{
			Login frame=new Login();
			frame.setSize(300,100);
			frame.setVisible(true);
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		
					
		
		
					
	}		
}

